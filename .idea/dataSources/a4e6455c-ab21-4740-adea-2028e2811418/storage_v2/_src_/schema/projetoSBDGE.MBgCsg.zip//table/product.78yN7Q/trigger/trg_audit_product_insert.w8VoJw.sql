create definer = srhalvs@localhost trigger trg_audit_product_insert
    after insert
    on product
    for each row
BEGIN
    INSERT INTO audit_log (
        user_id,
        operation,
        table_name,
        record_id,
        old_value,
        new_value
    )
    VALUES (
               @current_user_id,
               'INSERT',
               'product',
               NEW.id_product,
               NULL,
               JSON_OBJECT(
                       'category_id', NEW.category_id,
                       'supplier_id', NEW.supplier_id,
                       'name', NEW.name,
                       'description', NEW.description,
                       'sku', NEW.sku,
                       'type', NEW.type,
                       'price', NEW.price,
                       'is_active', NEW.is_active,
                       'created_at', NEW.created_at,
                       'updated_at', NEW.updated_at
               )
           );
END;

