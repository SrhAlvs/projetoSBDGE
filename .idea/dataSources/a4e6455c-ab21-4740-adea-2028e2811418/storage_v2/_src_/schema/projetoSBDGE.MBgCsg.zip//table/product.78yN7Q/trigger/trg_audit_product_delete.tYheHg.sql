create definer = srhalvs@localhost trigger trg_audit_product_delete
    after delete
    on product
    for each row
BEGIN
    INSERT INTO audit_log (
        user_id,
        operation,
        table_name,
        record_id,
        old_value,
        new_value
    )
    VALUES (
               @current_user_id,
               'DELETE',
               'product',
               OLD.id_product,
               JSON_OBJECT(
                       'category_id', OLD.category_id,
                       'supplier_id', OLD.supplier_id,
                       'name', OLD.name,
                       'description', OLD.description,
                       'sku', OLD.sku,
                       'type', OLD.type,
                       'price', OLD.price,
                       'is_active', OLD.is_active,
                       'created_at', OLD.created_at,
                       'updated_at', OLD.updated_at
               ),
               NULL
           );
END;

