create definer = srhalvs@localhost trigger trg_audit_product_update
    after update
    on product
    for each row
BEGIN
    INSERT INTO audit_log (
        user_id,
        operation,
        table_name,
        record_id,
        old_value,
        new_value
    )
    VALUES (
               @current_user_id,
               'UPDATE',
               'product',
               OLD.id_product,
               JSON_OBJECT(
                       'category_id', OLD.category_id,
                       'supplier_id', OLD.supplier_id,
                       'name', OLD.name,
                       'description', OLD.description,
                       'sku', OLD.sku,
                       'type', OLD.type,
                       'price', OLD.price,
                       'is_active', OLD.is_active,
                       'created_at', OLD.created_at,
                       'updated_at', OLD.updated_at
               ),
               JSON_OBJECT(
                       'category_id', NEW.category_id,
                       'supplier_id', NEW.supplier_id,
                       'name', NEW.name,
                       'description', NEW.description,
                       'sku', NEW.sku,
                       'type', NEW.type,
                       'price', NEW.price,
                       'is_active', NEW.is_active,
                       'created_at', NEW.created_at,
                       'updated_at', NEW.updated_at
               )
           );
END;

