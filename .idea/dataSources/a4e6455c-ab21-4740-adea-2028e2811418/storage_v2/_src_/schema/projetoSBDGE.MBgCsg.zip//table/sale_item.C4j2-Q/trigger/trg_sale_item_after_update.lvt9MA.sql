create definer = srhalvs@localhost trigger trg_sale_item_after_update
    after update
    on sale_item
    for each row
BEGIN
    UPDATE sale
    SET total_amount = (
        SELECT COALESCE(SUM(subtotal), 0.00)
        FROM sale_item
        WHERE sale_id = NEW.sale_id
    )
    WHERE id_sale = NEW.sale_id;

    -- Caso o item tenha sido transferido para outra venda
    IF OLD.sale_id <> NEW.sale_id THEN
        UPDATE sale
        SET total_amount = (
            SELECT COALESCE(SUM(subtotal), 0.00)
            FROM sale_item
            WHERE sale_id = OLD.sale_id
        )
        WHERE id_sale = OLD.sale_id;
    END IF;
END;

