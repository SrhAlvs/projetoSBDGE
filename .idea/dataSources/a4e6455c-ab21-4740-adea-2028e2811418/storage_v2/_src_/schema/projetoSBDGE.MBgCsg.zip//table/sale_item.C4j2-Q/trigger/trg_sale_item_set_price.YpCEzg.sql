create definer = srhalvs@localhost trigger trg_sale_item_set_price
    before insert
    on sale_item
    for each row
BEGIN
    IF NEW.unit_price IS NULL THEN
        SET NEW.unit_price = (
            SELECT price
            FROM product
            WHERE id_product = NEW.product_id
        );
    END IF;
END;

