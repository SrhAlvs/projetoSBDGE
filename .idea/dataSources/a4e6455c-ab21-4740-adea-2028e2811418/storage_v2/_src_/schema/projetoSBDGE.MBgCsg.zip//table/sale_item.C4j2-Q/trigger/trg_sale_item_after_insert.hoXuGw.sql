create definer = srhalvs@localhost trigger trg_sale_item_after_insert
    after insert
    on sale_item
    for each row
BEGIN
    UPDATE sale
    SET total_amount = (
        SELECT COALESCE(SUM(subtotal), 0.00)
        FROM sale_item
        WHERE sale_id = NEW.sale_id
    )
    WHERE id_sale = NEW.sale_id;
END;

